@echo off
REM ============================================================
REM convertBud
REM Copyright (C) 2026 Archie Garlick-Freeston
REM
REM This program is free software: you can redistribute it and/or modify
REM it under the terms of the GNU General Public License as published by
REM the Free Software Foundation, either version 3 of the License, or
REM (at your option) any later version.
REM
REM This program is distributed in the hope that it will be useful,
REM but WITHOUT ANY WARRANTY; without even the implied warranty of
REM MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
REM GNU General Public License for more details.
REM
REM You should have received a copy of the GNU General Public License
REM along with this program. If not, see <https://www.gnu.org/licenses/>.
REM
REM The full license text is included in LICENSE.
REM ============================================================

setlocal EnableExtensions DisableDelayedExpansion
title convertBud - converter

REM ============================================================
REM configuration
REM ============================================================

set "BASE=%~dp0"
set "INPUT_DIR=%BASE%input"
set "OUTPUT_DIR=%BASE%output"
set "FFMPEG=%BASE%ffmpeg\bin\ffmpeg.exe"
set "MAX_BATCH=50"
set "LICENSE_FILE=%BASE%LICENSE"

REM ============================================================
REM startup checks
REM ============================================================

if not exist "%FFMPEG%" (
    echo.
    echo ffmpeg could not be found
    echo.
    echo expected location:
    echo "%BASE%ffmpeg\bin\ffmpeg.exe"
    echo.
    echo check the ffmpeg path in this .bat file
    echo.
    pause
    exit /b 1
)

if not exist "%INPUT_DIR%\" mkdir "%INPUT_DIR%" >nul 2>&1
if not exist "%OUTPUT_DIR%\" mkdir "%OUTPUT_DIR%" >nul 2>&1

if not exist "%INPUT_DIR%\" (
    echo.
    echo err: input folder could not be created
    echo.
    pause
    exit /b 1
)

if not exist "%OUTPUT_DIR%\" (
    echo.
    echo err: output folder could not be created
    echo.
    pause
    exit /b 1
)

REM ============================================================
REM main menu
REM ============================================================

:START
cls
echo.
echo Copyright (C) 2026 Archie Garlick-Freeston
echo This program comes with no warranty.
echo Licensed under the GNU General Public License V3; choose option 4 to view the licence and warranty.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo.
echo.
echo choose a conversion type:
echo.
echo   1. audio
echo   2. images
echo   3. text files
echo   4. licence / warranty
echo   5. exit
echo.
set "MENU_OPTION="
set /p "MENU_OPTION=option: "
set "MENU_OPTION=%MENU_OPTION:"=%"
set "MENU_OPTION=%MENU_OPTION: =%"

if "%MENU_OPTION%"=="1" goto AUDIO_MENU
if "%MENU_OPTION%"=="2" goto IMAGE_MENU
if "%MENU_OPTION%"=="3" goto TEXT_MENU
if "%MENU_OPTION%"=="4" goto LEGAL
if "%MENU_OPTION%"=="5" exit /b 0

echo.
echo err: invalid option
timeout /t 2 /nobreak >nul
goto START

REM ============================================================
REM licence / warranty
REM ============================================================

:LEGAL
cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo          licence / warranty
echo.
echo Copyright (C) 2026 Archie Garlick-Freeston
echo.
echo This program is free software and may be redistributed and modified under the terms
echo of the GNU General Public License V3.
echo.
echo This program comes with absolutely no warranty to the extent permitted by applicable law.
echo.
echo Full license text:
echo %LICENSE_FILE%
echo.

if exist "%LICENSE_FILE%" (
    more < "%LICENSE_FILE%"
) else (
    echo err: LICENSE file could not be found
    echo.
    echo the license text should be distributed alongside convertBud.
    echo. 
)

echo.
echo.
pause
goto START

REM ============================================================
REM audio menu
REM ============================================================

:AUDIO_MENU
cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo                audio
echo.
echo   1. single conversion
echo   2. batch conversion
echo   3. back to main menu
echo.
set "MENU_OPTION="
set /p "MENU_OPTION=option: "
set "MENU_OPTION=%MENU_OPTION:"=%"
set "MENU_OPTION=%MENU_OPTION: =%"

if "%MENU_OPTION%"=="1" goto AUDIO_SINGLE
if "%MENU_OPTION%"=="2" goto AUDIO_BATCH
if "%MENU_OPTION%"=="3" goto START

echo.
echo err: invalid option
timeout /t 2 /nobreak >nul
goto AUDIO_MENU

REM ============================================================
REM audio single
REM ============================================================

:AUDIO_SINGLE
cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo                audio
echo.
echo files must be placed in:
echo "%INPUT_DIR%"
echo.
echo supported input types:
echo .wav  .mp3  .flac  .m4a  .aac  .ogg
echo.
echo enter the filename you want to convert
echo example: song.wav
echo.

set "INPUT_NAME="
set /p "INPUT_NAME=file: "
set "INPUT_NAME=%INPUT_NAME:"=%"

if not defined INPUT_NAME (
    echo.
    echo no filename entered
    timeout /t 2 /nobreak >nul
    goto AUDIO_MENU
)

set "CHECK_NAME=%INPUT_NAME%"
call :VALIDATE_FILENAME
if errorlevel 1 (
    echo.
    echo err: invalid filename
    echo.
    echo enter a filename only - no path, wildcard, or reserved characters
    timeout /t 3 /nobreak >nul
    goto AUDIO_SINGLE
)

if not exist "%INPUT_DIR%\%INPUT_NAME%" (
    echo.
    echo err: file was not found in input folder
    timeout /t 3 /nobreak >nul
    goto AUDIO_SINGLE
)

if exist "%INPUT_DIR%\%INPUT_NAME%\" (
    echo.
    echo err: that is a folder, not a file
    timeout /t 3 /nobreak >nul
    goto AUDIO_SINGLE
)

for %%F in ("%INPUT_DIR%\%INPUT_NAME%") do (
    set "SOURCE_FILE=%%~fF"
    set "BASE_NAME=%%~nF"
    set "SOURCE_EXT=%%~xF"
)

if /I "%SOURCE_EXT%"==".wav" goto AUDIO_SINGLE_FORMAT
if /I "%SOURCE_EXT%"==".mp3" goto AUDIO_SINGLE_FORMAT
if /I "%SOURCE_EXT%"==".flac" goto AUDIO_SINGLE_FORMAT
if /I "%SOURCE_EXT%"==".m4a" goto AUDIO_SINGLE_FORMAT
if /I "%SOURCE_EXT%"==".aac" goto AUDIO_SINGLE_FORMAT
if /I "%SOURCE_EXT%"==".ogg" goto AUDIO_SINGLE_FORMAT

echo.
echo err: convertBud does not currently support:
echo "%SOURCE_EXT%"
echo.
echo supported input types are:
echo .wav  .mp3  .flac  .m4a  .aac  .ogg
echo.
pause
goto AUDIO_MENU

:AUDIO_SINGLE_FORMAT
cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo                audio
echo.
echo input file:
echo "%INPUT_NAME%"
echo.
echo detected type:
echo "%SOURCE_EXT%"
echo.
echo available conversion results:
echo.
echo   .mp3
echo   .wav
echo   .flac
echo   .m4a
echo   .ogg
echo   .mp4   [video with optional accompanying image]
echo.
echo enter one of the file types above
echo accepted: mp3 / .mp3 / MP3 / .MP3
echo.

set "OUTPUT_EXT="
set /p "OUTPUT_EXT=output format: "
call :NORMALIZE_EXTENSION

if not defined OUTPUT_EXT (
    echo.
    echo err: no output format entered
    timeout /t 2 /nobreak >nul
    goto AUDIO_SINGLE_FORMAT
)

if /I not "%OUTPUT_EXT%"=="mp3" if /I not "%OUTPUT_EXT%"=="wav" if /I not "%OUTPUT_EXT%"=="flac" if /I not "%OUTPUT_EXT%"=="m4a" if /I not "%OUTPUT_EXT%"=="ogg" if /I not "%OUTPUT_EXT%"=="mp4" (
    echo.
    echo err: output format not supported
    timeout /t 2 /nobreak >nul
    goto AUDIO_SINGLE_FORMAT
)

set "IMAGE_FILE="
if /I "%OUTPUT_EXT%"=="mp4" call :CHOOSE_IMAGE

set "CONVERT_MODE=single"
call :PREPARE_OUTPUT
if errorlevel 2 goto SINGLE_OUTPUT_EXISTS
if errorlevel 1 goto SINGLE_SAME_FORMAT

goto AUDIO_CONVERT

REM ============================================================
REM audio batch
REM ============================================================

:AUDIO_BATCH
cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo                audio
echo.
echo batch conversion converts every supported
echo audio file currently in the input folder
echo.
echo maximum files per batch:
echo %MAX_BATCH%
echo.
echo supported input types:
echo .wav  .mp3  .flac  .m4a  .aac  .ogg
echo.
echo available conversion results:
echo.
echo   .mp3
echo   .wav
echo   .flac
echo   .m4a
echo   .ogg
echo   .mp4   [video with optional accompanying image]
echo.
set "OUTPUT_EXT="
set /p "OUTPUT_EXT=output format: "
call :NORMALIZE_EXTENSION

if not defined OUTPUT_EXT (
    echo.
    echo err: no output format entered
    timeout /t 2 /nobreak >nul
    goto AUDIO_BATCH
)

if /I not "%OUTPUT_EXT%"=="mp3" if /I not "%OUTPUT_EXT%"=="wav" if /I not "%OUTPUT_EXT%"=="flac" if /I not "%OUTPUT_EXT%"=="m4a" if /I not "%OUTPUT_EXT%"=="ogg" if /I not "%OUTPUT_EXT%"=="mp4" (
    echo.
    echo err: output format not supported
    timeout /t 2 /nobreak >nul
    goto AUDIO_BATCH
)

set "IMAGE_FILE="
if /I "%OUTPUT_EXT%"=="mp4" call :CHOOSE_IMAGE

call :COUNT_AUDIO_FILES
if "%BATCH_COUNT%"=="0" (
    echo.
    echo no supported audio files were found in the input folder
    echo.
    pause
    goto AUDIO_MENU
)

if %BATCH_COUNT% GTR %MAX_BATCH% (
    echo.
    echo err: too many files for one batch
    echo.
    echo files found:
    echo %BATCH_COUNT%
    echo maximum allowed:
    echo %MAX_BATCH%
    echo.
    pause
    goto AUDIO_MENU
)

set "BATCH_CURRENT=0"
set "BATCH_SUCCESS=0"
set "BATCH_FAILED=0"
set "BATCH_SAME=0"
set "BATCH_SKIPPED=0"

cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo                audio
echo.
echo starting batch conversion
echo.
echo files found:
echo %BATCH_COUNT%
echo.
echo output format:
echo ".%OUTPUT_EXT%"
echo.
if /I "%OUTPUT_EXT%"=="mp4" (
    if defined IMAGE_FILE echo image: "%IMAGE_FILE%"
    if not defined IMAGE_FILE echo image: none - using black background
)
echo.

for %%F in (
    "%INPUT_DIR%\*.wav"
    "%INPUT_DIR%\*.mp3"
    "%INPUT_DIR%\*.flac"
    "%INPUT_DIR%\*.m4a"
    "%INPUT_DIR%\*.aac"
    "%INPUT_DIR%\*.ogg"
) do (
    if exist "%%~fF" if not exist "%%~fF\" (
        set "SOURCE_FILE=%%~fF"
        set "BASE_NAME=%%~nF"
        set "SOURCE_EXT=%%~xF"
        call :AUDIO_BATCH_FILE
    )
)

cls
echo.
echo _____________________________________
echo          batch conversion
echo              complete!
echo -------------------------------------
echo                audio
echo.
echo total files:
echo %BATCH_COUNT%
echo.
echo converted:
echo %BATCH_SUCCESS%
echo.
echo skipped - same filetype:
echo %BATCH_SAME%
echo.
echo skipped - output already exists:
echo %BATCH_SKIPPED%
echo.
echo failed:
echo %BATCH_FAILED%
echo.
echo output folder:
echo "%OUTPUT_DIR%"
echo.
pause
goto AUDIO_MENU

:AUDIO_BATCH_FILE
set /a BATCH_CURRENT+=1
echo converting %BATCH_CURRENT%/%BATCH_COUNT%:
echo "%BASE_NAME%%SOURCE_EXT%" to ".%OUTPUT_EXT%"

set "CONVERT_MODE=batch"
call :PREPARE_OUTPUT
if errorlevel 2 (
    set /a BATCH_SKIPPED+=1
    echo skipped - output already exists
    echo.
    exit /b 0
)
if errorlevel 1 (
    set /a BATCH_SAME+=1
    echo skipped - same filetype
    echo.
    exit /b 0
)

call :AUDIO_CONVERT
echo.
exit /b 0

:COUNT_AUDIO_FILES
set "BATCH_COUNT=0"
for %%F in (
    "%INPUT_DIR%\*.wav"
    "%INPUT_DIR%\*.mp3"
    "%INPUT_DIR%\*.flac"
    "%INPUT_DIR%\*.m4a"
    "%INPUT_DIR%\*.aac"
    "%INPUT_DIR%\*.ogg"
) do (
    if exist "%%~fF" if not exist "%%~fF\" set /a BATCH_COUNT+=1
)
exit /b 0

REM ============================================================
REM image menu
REM ============================================================

:IMAGE_MENU
cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo               images
echo.
echo   1. single conversion
echo   2. batch conversion
echo   3. back to main menu
echo.
set "MENU_OPTION="
set /p "MENU_OPTION=option: "
set "MENU_OPTION=%MENU_OPTION:"=%"
set "MENU_OPTION=%MENU_OPTION: =%"

if "%MENU_OPTION%"=="1" goto IMAGE_SINGLE
if "%MENU_OPTION%"=="2" goto IMAGE_BATCH
if "%MENU_OPTION%"=="3" goto START

echo.
echo err: invalid option
timeout /t 2 /nobreak >nul
goto IMAGE_MENU

REM ============================================================
REM image single
REM ============================================================

:IMAGE_SINGLE
cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo               images
echo.
echo files must be placed in:
echo "%INPUT_DIR%"
echo.
echo supported input types:
echo .jpg  .jpeg  .png  .bmp  .webp  .gif  .tif  .tiff
echo.
echo enter the filename you want to convert
echo example: picture.png
echo.

set "INPUT_NAME="
set /p "INPUT_NAME=file: "
set "INPUT_NAME=%INPUT_NAME:"=%"

if not defined INPUT_NAME (
    echo.
    echo no filename entered
    timeout /t 2 /nobreak >nul
    goto IMAGE_MENU
)

set "CHECK_NAME=%INPUT_NAME%"
call :VALIDATE_FILENAME
if errorlevel 1 (
    echo.
    echo err: invalid filename
    echo.
    echo enter a filename only - no path, wildcard, or reserved characters
    timeout /t 3 /nobreak >nul
    goto IMAGE_SINGLE
)

if not exist "%INPUT_DIR%\%INPUT_NAME%" (
    echo.
    echo err: file was not found in input folder
    timeout /t 3 /nobreak >nul
    goto IMAGE_SINGLE
)

if exist "%INPUT_DIR%\%INPUT_NAME%\" (
    echo.
    echo err: that is a folder, not a file
    timeout /t 3 /nobreak >nul
    goto IMAGE_SINGLE
)

for %%F in ("%INPUT_DIR%\%INPUT_NAME%") do (
    set "SOURCE_FILE=%%~fF"
    set "BASE_NAME=%%~nF"
    set "SOURCE_EXT=%%~xF"
)

if /I "%SOURCE_EXT%"==".jpg" goto IMAGE_SINGLE_FORMAT
if /I "%SOURCE_EXT%"==".jpeg" goto IMAGE_SINGLE_FORMAT
if /I "%SOURCE_EXT%"==".png" goto IMAGE_SINGLE_FORMAT
if /I "%SOURCE_EXT%"==".bmp" goto IMAGE_SINGLE_FORMAT
if /I "%SOURCE_EXT%"==".webp" goto IMAGE_SINGLE_FORMAT
if /I "%SOURCE_EXT%"==".gif" goto IMAGE_SINGLE_FORMAT
if /I "%SOURCE_EXT%"==".tif" goto IMAGE_SINGLE_FORMAT
if /I "%SOURCE_EXT%"==".tiff" goto IMAGE_SINGLE_FORMAT

echo.
echo err: convertBud does not currently support:
echo "%SOURCE_EXT%"
echo.
echo supported input types are:
echo .jpg  .jpeg  .png  .bmp  .webp  .gif  .tif  .tiff
echo.
pause
goto IMAGE_MENU

:IMAGE_SINGLE_FORMAT
cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo               images
echo.
echo input file:
echo "%INPUT_NAME%"
echo.
echo detected type:
echo "%SOURCE_EXT%"
echo.
echo available conversion results:
echo.
echo   .jpg
echo   .jpeg
echo   .png
echo   .bmp
echo   .webp
echo   .gif
echo   .tif
echo   .tiff
echo.
echo note: converting an animated image to a still
echo format keeps only the first frame
echo.
echo enter one of the file types above
echo accepted: png / .png / PNG / .PNG
echo.

set "OUTPUT_EXT="
set /p "OUTPUT_EXT=output format: "
call :NORMALIZE_EXTENSION

if not defined OUTPUT_EXT (
    echo.
    echo err: no output format entered
    timeout /t 2 /nobreak >nul
    goto IMAGE_SINGLE_FORMAT
)

if /I not "%OUTPUT_EXT%"=="jpg" if /I not "%OUTPUT_EXT%"=="jpeg" if /I not "%OUTPUT_EXT%"=="png" if /I not "%OUTPUT_EXT%"=="bmp" if /I not "%OUTPUT_EXT%"=="webp" if /I not "%OUTPUT_EXT%"=="gif" if /I not "%OUTPUT_EXT%"=="tif" if /I not "%OUTPUT_EXT%"=="tiff" (
    echo.
    echo err: output format not supported
    timeout /t 2 /nobreak >nul
    goto IMAGE_SINGLE_FORMAT
)

set "CONVERT_MODE=single"
call :PREPARE_OUTPUT
if errorlevel 2 goto SINGLE_OUTPUT_EXISTS
if errorlevel 1 goto SINGLE_SAME_FORMAT

goto IMAGE_CONVERT

REM ============================================================
REM image batch
REM ============================================================

:IMAGE_BATCH
cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo               images
echo.
echo batch conversion converts every supported
echo image file currently in the input folder
echo.
echo maximum files per batch:
echo %MAX_BATCH%
echo.
echo supported input types:
echo .jpg  .jpeg  .png  .bmp  .webp  .gif  .tif  .tiff
echo.
echo available conversion results:
echo.
echo   .jpg
echo   .jpeg
echo   .png
echo   .bmp
echo   .webp
echo   .gif
echo   .tif
echo   .tiff
echo.
set "OUTPUT_EXT="
set /p "OUTPUT_EXT=output format: "
call :NORMALIZE_EXTENSION

if not defined OUTPUT_EXT (
    echo.
    echo err: no output format entered
    timeout /t 2 /nobreak >nul
    goto IMAGE_BATCH
)

if /I not "%OUTPUT_EXT%"=="jpg" if /I not "%OUTPUT_EXT%"=="jpeg" if /I not "%OUTPUT_EXT%"=="png" if /I not "%OUTPUT_EXT%"=="bmp" if /I not "%OUTPUT_EXT%"=="webp" if /I not "%OUTPUT_EXT%"=="gif" if /I not "%OUTPUT_EXT%"=="tif" if /I not "%OUTPUT_EXT%"=="tiff" (
    echo.
    echo err: output format not supported
    timeout /t 2 /nobreak >nul
    goto IMAGE_BATCH
)

call :COUNT_IMAGE_FILES
if "%BATCH_COUNT%"=="0" (
    echo.
    echo no supported image files were found in the input folder
    echo.
    pause
    goto IMAGE_MENU
)

if %BATCH_COUNT% GTR %MAX_BATCH% (
    echo.
    echo err: too many files for one batch
    echo.
    echo files found:
    echo %BATCH_COUNT%
    echo maximum allowed:
    echo %MAX_BATCH%
    echo.
    pause
    goto IMAGE_MENU
)

set "BATCH_CURRENT=0"
set "BATCH_SUCCESS=0"
set "BATCH_FAILED=0"
set "BATCH_SAME=0"
set "BATCH_SKIPPED=0"

cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo               images
echo.
echo starting batch conversion
echo.
echo files found:
echo %BATCH_COUNT%
echo.
echo output format:
echo ".%OUTPUT_EXT%"
echo.

for %%F in (
    "%INPUT_DIR%\*.jpg"
    "%INPUT_DIR%\*.jpeg"
    "%INPUT_DIR%\*.png"
    "%INPUT_DIR%\*.bmp"
    "%INPUT_DIR%\*.webp"
    "%INPUT_DIR%\*.gif"
    "%INPUT_DIR%\*.tif"
    "%INPUT_DIR%\*.tiff"
) do (
    if exist "%%~fF" if not exist "%%~fF\" (
        set "SOURCE_FILE=%%~fF"
        set "BASE_NAME=%%~nF"
        set "SOURCE_EXT=%%~xF"
        call :IMAGE_BATCH_FILE
    )
)

cls
echo.
echo _____________________________________
echo          batch conversion
echo              complete!
echo -------------------------------------
echo               images
echo.
echo total files:
echo %BATCH_COUNT%
echo.
echo converted:
echo %BATCH_SUCCESS%
echo.
echo skipped - same filetype:
echo %BATCH_SAME%
echo.
echo skipped - output already exists:
echo %BATCH_SKIPPED%
echo.
echo failed:
echo %BATCH_FAILED%
echo.
echo output folder:
echo "%OUTPUT_DIR%"
echo.
pause
goto IMAGE_MENU

:IMAGE_BATCH_FILE
set /a BATCH_CURRENT+=1
echo converting %BATCH_CURRENT%/%BATCH_COUNT%:
echo "%BASE_NAME%%SOURCE_EXT%" to ".%OUTPUT_EXT%"

set "CONVERT_MODE=batch"
call :PREPARE_OUTPUT
if errorlevel 2 (
    set /a BATCH_SKIPPED+=1
    echo skipped - output already exists
    echo.
    exit /b 0
)
if errorlevel 1 (
    set /a BATCH_SAME+=1
    echo skipped - same filetype
    echo.
    exit /b 0
)

call :IMAGE_CONVERT
echo.
exit /b 0

:COUNT_IMAGE_FILES
set "BATCH_COUNT=0"
for %%F in (
    "%INPUT_DIR%\*.jpg"
    "%INPUT_DIR%\*.jpeg"
    "%INPUT_DIR%\*.png"
    "%INPUT_DIR%\*.bmp"
    "%INPUT_DIR%\*.webp"
    "%INPUT_DIR%\*.gif"
    "%INPUT_DIR%\*.tif"
    "%INPUT_DIR%\*.tiff"
) do (
    if exist "%%~fF" if not exist "%%~fF\" set /a BATCH_COUNT+=1
)
exit /b 0

REM ============================================================
REM text menu - intentionally single-file only
REM ============================================================

:TEXT_MENU
cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo             text files
echo.
echo text conversion is single-file only
echo.
echo disclaimer:
echo convertBud does not translate, parse, or
echo reformat the contents of text files
echo.
echo it copies the file byte-for-byte and gives
echo the copy the new extension you choose
echo.
echo this means the destination format might not
echo consider the copied contents valid
echo.
echo   1. text conversion
echo   2. back to main menu
echo.
set "MENU_OPTION="
set /p "MENU_OPTION=option: "
set "MENU_OPTION=%MENU_OPTION:"=%"
set "MENU_OPTION=%MENU_OPTION: =%"

if "%MENU_OPTION%"=="1" goto TEXT_SINGLE
if "%MENU_OPTION%"=="2" goto START

echo.
echo err: invalid option
timeout /t 2 /nobreak >nul
goto TEXT_MENU

REM ============================================================
REM text single
REM ============================================================

:TEXT_SINGLE
cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo             text files
echo.
echo enter the filename you want to convert
echo.
echo any text-based file extension may be entered
echo.
echo examples:
echo .txt  .md  .csv  .json  .xml  .html
echo .css  .js   .py   .c    .cpp   .ini
echo.

set "INPUT_NAME="
set /p "INPUT_NAME=file: "
set "INPUT_NAME=%INPUT_NAME:"=%"

if not defined INPUT_NAME (
    echo.
    echo no filename entered
    timeout /t 2 /nobreak >nul
    goto TEXT_MENU
)

set "CHECK_NAME=%INPUT_NAME%"
call :VALIDATE_FILENAME
if errorlevel 1 (
    echo.
    echo err: invalid filename
    echo.
    echo enter a filename only - no path, wildcard, or reserved characters
    timeout /t 3 /nobreak >nul
    goto TEXT_SINGLE
)

if not exist "%INPUT_DIR%\%INPUT_NAME%" (
    echo.
    echo err: file was not found in input folder
    timeout /t 3 /nobreak >nul
    goto TEXT_SINGLE
)

if exist "%INPUT_DIR%\%INPUT_NAME%\" (
    echo.
    echo err: that is a folder, not a file
    timeout /t 3 /nobreak >nul
    goto TEXT_SINGLE
)

for %%F in ("%INPUT_DIR%\%INPUT_NAME%") do (
    set "SOURCE_FILE=%%~fF"
    set "BASE_NAME=%%~nF"
    set "SOURCE_EXT=%%~xF"
)

cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo             text files
echo.
echo input file:
echo "%INPUT_NAME%"
echo.
echo output can use any extension
echo.
echo examples:
echo .txt
echo .md
echo .html
echo .json
echo.
echo disclaimer:
echo this copies the text exactly
echo it does not translate or reformat it
echo.

set "OUTPUT_EXT="
set /p "OUTPUT_EXT=output format: "
call :NORMALIZE_EXTENSION

if not defined OUTPUT_EXT (
    echo.
    echo err: no output format entered
    timeout /t 2 /nobreak >nul
    goto TEXT_SINGLE
)

call :VALIDATE_EXTENSION
if errorlevel 1 (
    echo.
    echo err: invalid output extension
    echo.
    echo use a simple extension without paths or special characters
    timeout /t 3 /nobreak >nul
    goto TEXT_SINGLE
)

if /I "%SOURCE_EXT%"==".%OUTPUT_EXT%" (
    echo.
    echo you chose to convert to the same filetype
    echo restarting...
    echo.
    pause
    goto START
)

set "CONVERT_MODE=single"
call :PREPARE_OUTPUT
if errorlevel 2 goto SINGLE_OUTPUT_EXISTS

goto TEXT_CONVERT

REM ============================================================
REM accompanying image for audio -> mp4
REM ============================================================

:CHOOSE_IMAGE
set "IMAGE_FILE="
cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo            image settings
echo.
echo use an image for the mp4?
echo.
echo   y. yes
echo   n. no
echo.
echo supported image types:
echo .jpg  .jpeg  .png  .bmp  .webp
echo.
echo images must be placed in:
echo "%OUTPUT_DIR%"
echo.

set "USE_IMAGE="
set /p "USE_IMAGE=option: "
set "USE_IMAGE=%USE_IMAGE:"=%"
set "USE_IMAGE=%USE_IMAGE: =%"

if /I "%USE_IMAGE%"=="n" exit /b 0
if /I "%USE_IMAGE%"=="no" exit /b 0
if /I "%USE_IMAGE%"=="y" goto FIND_IMAGES
if /I "%USE_IMAGE%"=="yes" goto FIND_IMAGES

echo.
echo err: invalid option
timeout /t 2 /nobreak >nul
goto CHOOSE_IMAGE

:FIND_IMAGES
set "IMAGE_COUNT=0"
set "LAST_IMAGE="

for %%F in (
    "%OUTPUT_DIR%\*.jpg"
    "%OUTPUT_DIR%\*.jpeg"
    "%OUTPUT_DIR%\*.png"
    "%OUTPUT_DIR%\*.bmp"
    "%OUTPUT_DIR%\*.webp"
) do (
    if exist "%%~fF" if not exist "%%~fF\" (
        set /a IMAGE_COUNT+=1
        set "LAST_IMAGE=%%~fF"
    )
)

if "%IMAGE_COUNT%"=="0" (
    echo.
    echo no supported images were found in output
    echo.
    echo supported image types:
    echo .jpg  .jpeg  .png  .bmp  .webp
    echo.
    echo using black background instead
    echo.
    pause
    exit /b 0
)

if "%IMAGE_COUNT%"=="1" (
    set "IMAGE_FILE=%LAST_IMAGE%"
    echo.
    echo image selected:
    echo "%IMAGE_FILE%"
    echo.
    timeout /t 2 /nobreak >nul
    exit /b 0
)

cls
echo.
echo _____________________________________
echo              convertBud
echo -------------------------------------
echo            image settings
echo.
echo multiple images were found
echo.
echo available images:
echo.

for %%F in (
    "%OUTPUT_DIR%\*.jpg"
    "%OUTPUT_DIR%\*.jpeg"
    "%OUTPUT_DIR%\*.png"
    "%OUTPUT_DIR%\*.bmp"
    "%OUTPUT_DIR%\*.webp"
) do (
    if exist "%%~fF" if not exist "%%~fF\" echo   "%%~nxF"
)

echo.
echo enter the filename of the image to use
echo.

set "IMAGE_NAME="
set /p "IMAGE_NAME=image: "
set "IMAGE_NAME=%IMAGE_NAME:"=%"

set "CHECK_NAME=%IMAGE_NAME%"
call :VALIDATE_FILENAME
if errorlevel 1 (
    echo.
    echo err: invalid image filename
    timeout /t 2 /nobreak >nul
    goto FIND_IMAGES
)

if not exist "%OUTPUT_DIR%\%IMAGE_NAME%" (
    echo.
    echo err: image was not found in output folder
    timeout /t 2 /nobreak >nul
    goto FIND_IMAGES
)

if exist "%OUTPUT_DIR%\%IMAGE_NAME%\" (
    echo.
    echo err: that is a folder, not an image
    timeout /t 2 /nobreak >nul
    goto FIND_IMAGES
)

for %%F in ("%OUTPUT_DIR%\%IMAGE_NAME%") do set "IMAGE_EXT=%%~xF"

if /I not "%IMAGE_EXT%"==".jpg" if /I not "%IMAGE_EXT%"==".jpeg" if /I not "%IMAGE_EXT%"==".png" if /I not "%IMAGE_EXT%"==".bmp" if /I not "%IMAGE_EXT%"==".webp" (
    echo.
    echo err: file is not a supported image
    timeout /t 2 /nobreak >nul
    goto FIND_IMAGES
)

set "IMAGE_FILE=%OUTPUT_DIR%\%IMAGE_NAME%"
echo.
echo image selected:
echo "%IMAGE_FILE%"
echo.
timeout /t 2 /nobreak >nul
exit /b 0

REM ============================================================
REM shared output checks
REM return 0 = ready, 1 = same format, 2 = output exists
REM ============================================================

:PREPARE_OUTPUT
set "OUTPUT_FILE=%OUTPUT_DIR%\%BASE_NAME%.%OUTPUT_EXT%"

if /I "%SOURCE_EXT%"==".%OUTPUT_EXT%" exit /b 1
if exist "%OUTPUT_FILE%" exit /b 2

exit /b 0

:SINGLE_SAME_FORMAT
echo.
echo you chose to convert to the same filetype
echo restarting...
echo.
pause
goto START

:SINGLE_OUTPUT_EXISTS
cls
echo.
echo ____________________________________
echo              convertBud
echo ------------------------------------
echo.
echo output file with this name already exists:
echo.
echo "%OUTPUT_FILE%"
echo.
echo convertBud will not overwrite it
echo.
pause
goto START

REM ============================================================
REM audio conversion engine
REM ============================================================

:AUDIO_CONVERT

if /I "%CONVERT_MODE%"=="single" (
    cls
    echo.
    echo ____________________________________
    echo              convertBud
    echo ------------------------------------
    echo.
    echo - converting, please wait -
    echo.
    echo "%BASE_NAME%%SOURCE_EXT%"
    echo      to
    echo "%BASE_NAME%.%OUTPUT_EXT%"
    echo.
)

if /I "%OUTPUT_EXT%"=="mp3" goto AUDIO_MP3
if /I "%OUTPUT_EXT%"=="wav" goto AUDIO_WAV
if /I "%OUTPUT_EXT%"=="flac" goto AUDIO_FLAC
if /I "%OUTPUT_EXT%"=="m4a" goto AUDIO_M4A
if /I "%OUTPUT_EXT%"=="ogg" goto AUDIO_OGG
if /I "%OUTPUT_EXT%"=="mp4" goto AUDIO_MP4

if /I "%CONVERT_MODE%"=="batch" (
    set /a BATCH_FAILED+=1
    echo failed
    exit /b 1
)

goto CONVERSION_FAILED

:AUDIO_MP3
"%FFMPEG%" -hide_banner -loglevel error -nostats -nostdin -n -i "%SOURCE_FILE%" -c:a libmp3lame -b:a 320k "%OUTPUT_FILE%"
if errorlevel 1 goto AUDIO_FAILED
goto AUDIO_SUCCESS

:AUDIO_WAV
"%FFMPEG%" -hide_banner -loglevel error -nostats -nostdin -n -i "%SOURCE_FILE%" -c:a pcm_s16le "%OUTPUT_FILE%"
if errorlevel 1 goto AUDIO_FAILED
goto AUDIO_SUCCESS

:AUDIO_FLAC
"%FFMPEG%" -hide_banner -loglevel error -nostats -nostdin -n -i "%SOURCE_FILE%" -c:a flac "%OUTPUT_FILE%"
if errorlevel 1 goto AUDIO_FAILED
goto AUDIO_SUCCESS

:AUDIO_M4A
"%FFMPEG%" -hide_banner -loglevel error -nostats -nostdin -n -i "%SOURCE_FILE%" -c:a aac -b:a 320k "%OUTPUT_FILE%"
if errorlevel 1 goto AUDIO_FAILED
goto AUDIO_SUCCESS

:AUDIO_OGG
"%FFMPEG%" -hide_banner -loglevel error -nostats -nostdin -n -i "%SOURCE_FILE%" -c:a libvorbis -q:a 6 "%OUTPUT_FILE%"
if errorlevel 1 goto AUDIO_FAILED
goto AUDIO_SUCCESS

:AUDIO_MP4
if defined IMAGE_FILE goto AUDIO_MP4_IMAGE

"%FFMPEG%" -hide_banner -loglevel error -nostats -nostdin -n -f lavfi -i "color=c=black:s=1920x1080:r=1" -i "%SOURCE_FILE%" -map 0:v:0 -map 1:a:0 -c:v libx264 -preset medium -tune stillimage -crf 18 -pix_fmt yuv420p -c:a aac -b:a 320k -ar 48000 -shortest -movflags +faststart "%OUTPUT_FILE%"
if errorlevel 1 goto AUDIO_FAILED
goto AUDIO_SUCCESS

:AUDIO_MP4_IMAGE
"%FFMPEG%" -hide_banner -loglevel error -nostats -nostdin -n -loop 1 -framerate 1 -i "%IMAGE_FILE%" -i "%SOURCE_FILE%" -map 0:v:0 -map 1:a:0 -vf "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2" -c:v libx264 -preset medium -tune stillimage -crf 18 -pix_fmt yuv420p -c:a aac -b:a 320k -ar 48000 -shortest -movflags +faststart "%OUTPUT_FILE%"
if errorlevel 1 goto AUDIO_FAILED
goto AUDIO_SUCCESS

:AUDIO_SUCCESS
if /I "%CONVERT_MODE%"=="batch" (
    set /a BATCH_SUCCESS+=1
    echo complete
    exit /b 0
)

cls
echo.
echo ____________________________________
echo          conversion success!
echo.
echo output:
echo "%OUTPUT_FILE%"
echo.
pause
exit /b 0

:AUDIO_FAILED
if exist "%OUTPUT_FILE%" del /q "%OUTPUT_FILE%" >nul 2>&1
if /I "%CONVERT_MODE%"=="batch" (
    set /a BATCH_FAILED+=1
    echo failed
    exit /b 1
)
goto CONVERSION_FAILED

REM ============================================================
REM image conversion engine
REM ============================================================

:IMAGE_CONVERT

if /I "%CONVERT_MODE%"=="single" (
    cls
    echo.
    echo ____________________________________
    echo              convertBud
    echo ------------------------------------
    echo.
    echo - converting, please wait -
    echo.
    echo "%BASE_NAME%%SOURCE_EXT%"
    echo      to
    echo "%BASE_NAME%.%OUTPUT_EXT%"
    echo.
)

if /I "%OUTPUT_EXT%"=="gif" goto IMAGE_GIF

"%FFMPEG%" -hide_banner -loglevel error -nostats -nostdin -n -i "%SOURCE_FILE%" -frames:v 1 "%OUTPUT_FILE%"
if errorlevel 1 goto IMAGE_FAILED
goto IMAGE_SUCCESS

:IMAGE_GIF
"%FFMPEG%" -hide_banner -loglevel error -nostats -nostdin -n -i "%SOURCE_FILE%" "%OUTPUT_FILE%"
if errorlevel 1 goto IMAGE_FAILED
goto IMAGE_SUCCESS

:IMAGE_SUCCESS
if /I "%CONVERT_MODE%"=="batch" (
    set /a BATCH_SUCCESS+=1
    echo complete
    exit /b 0
)

cls
echo.
echo ____________________________________
echo          conversion success!
echo.
echo output:
echo "%OUTPUT_FILE%"
echo.
pause
exit /b 0

:IMAGE_FAILED
if exist "%OUTPUT_FILE%" del /q "%OUTPUT_FILE%" >nul 2>&1
if /I "%CONVERT_MODE%"=="batch" (
    set /a BATCH_FAILED+=1
    echo failed
    exit /b 1
)
goto CONVERSION_FAILED

REM ============================================================
REM text conversion engine
REM ============================================================

:TEXT_CONVERT

if /I "%CONVERT_MODE%"=="single" (
    cls
    echo.
    echo ____________________________________
    echo              convertBud
    echo ------------------------------------
    echo.
    echo - copying text, please wait -
    echo.
    echo "%BASE_NAME%%SOURCE_EXT%"
    echo      to
    echo "%BASE_NAME%.%OUTPUT_EXT%"
    echo.
)

REM byte-for-byte copy; no parsing or reformatting
copy /b "%SOURCE_FILE%" "%OUTPUT_FILE%" >nul
if errorlevel 1 goto TEXT_FAILED

cls
echo.
echo ____________________________________
echo          conversion success!
echo.
echo output:
echo "%OUTPUT_FILE%"
echo.
echo note:
echo the file contents were copied exactly
echo.
pause
goto TEXT_MENU

:TEXT_FAILED
if exist "%OUTPUT_FILE%" del /q "%OUTPUT_FILE%" >nul 2>&1
cls
echo.
echo ____________________________________
echo          conversion failed!
echo.
echo windows could not copy the file
echo.
pause
goto TEXT_MENU

REM ============================================================
REM extension helpers
REM ============================================================

:NORMALIZE_EXTENSION
set "OUTPUT_EXT=%OUTPUT_EXT:"=%"
set "OUTPUT_EXT=%OUTPUT_EXT: =%"
if "%OUTPUT_EXT:~0,1%"=="." set "OUTPUT_EXT=%OUTPUT_EXT:~1%"
exit /b 0

:VALIDATE_EXTENSION
set "CHECK_EXT=%OUTPUT_EXT%"
if not defined CHECK_EXT exit /b 1
if not "%CHECK_EXT:\=%"=="%CHECK_EXT%" exit /b 1
if not "%CHECK_EXT:/=%"=="%CHECK_EXT%" exit /b 1
if not "%CHECK_EXT::=%"=="%CHECK_EXT%" exit /b 1
if not "%CHECK_EXT:%%=%"=="%CHECK_EXT%" exit /b 1
if not "%CHECK_EXT:*=%"=="%CHECK_EXT%" exit /b 1
if not "%CHECK_EXT:?=%"=="%CHECK_EXT%" exit /b 1
if not "%CHECK_EXT:|=%"=="%CHECK_EXT%" exit /b 1
if not "%CHECK_EXT:<=%"=="%CHECK_EXT%" exit /b 1
if not "%CHECK_EXT:>=%"=="%CHECK_EXT%" exit /b 1
if not "%CHECK_EXT:"=%"=="%CHECK_EXT%" exit /b 1
if not "%CHECK_EXT:&=%"=="%CHECK_EXT%" exit /b 1
if not "%CHECK_EXT:+=%"=="%CHECK_EXT%" exit /b 1
if not "%CHECK_EXT:(=%"=="%CHECK_EXT%" exit /b 1
if not "%CHECK_EXT:)=%"=="%CHECK_EXT%" exit /b 1
exit /b 0

:VALIDATE_FILENAME
set "CHECK_NAME_INVALID=0"
if not "%CHECK_NAME:\=%"=="%CHECK_NAME%" set "CHECK_NAME_INVALID=1"
if not "%CHECK_NAME:/=%"=="%CHECK_NAME%" set "CHECK_NAME_INVALID=1"
if not "%CHECK_NAME::=%"=="%CHECK_NAME%" set "CHECK_NAME_INVALID=1"
if not "%CHECK_NAME:*=%"=="%CHECK_NAME%" set "CHECK_NAME_INVALID=1"
if not "%CHECK_NAME:?=%"=="%CHECK_NAME%" set "CHECK_NAME_INVALID=1"
if not "%CHECK_NAME:"=%"=="%CHECK_NAME%" set "CHECK_NAME_INVALID=1"
if not "%CHECK_NAME:<=%"=="%CHECK_NAME%" set "CHECK_NAME_INVALID=1"
if not "%CHECK_NAME:>=%"=="%CHECK_NAME%" set "CHECK_NAME_INVALID=1"
if not "%CHECK_NAME:|=%"=="%CHECK_NAME%" set "CHECK_NAME_INVALID=1"

if "%CHECK_NAME_INVALID%"=="1" exit /b 1
exit /b 0

:CONVERSION_FAILED
echo.
echo ____________________________________
echo          conversion failed!
echo.
echo ffmpeg reported an error
echo.
echo any incomplete output was removed
echo.
pause
goto START
